import json

def lambda_handler(event, context):
    try:
        
        print("Evento recebido: ", json.dumps(event))

        
        method_arn = event.get("methodArn", "")
        print("Method ARN capturado: ", method_arn)

        # Verifica se o cabeçalho de autorização existe e começa com 'Bearer'
        authorization_header = event['headers'].get('authorization', '')
        if not authorization_header.startswith('Bearer '):
            print("Token inválido: o cabeçalho deve começar com 'Bearer'.")
            return generate_policy("user", "Deny", method_arn)

    
        token = authorization_header.split(' ')[1]  
        print("Token extraído:", token)
        
        if not token.isdigit() or len(token) != 11:
            print("Token inválido: não é numérico ou não possui 11 dígitos.")
            return generate_policy("user", "Deny", method_arn)

        # Token válido, gera a política para permitir o acesso
        policy = generate_policy("user", "Allow", method_arn)
        print("Policy gerada: ", json.dumps(policy))

        return policy

    except Exception as e:
        
        print(f"Erro ocorrido: {str(e)}")
        method_arn = event.get("methodArn", "")
        return generate_policy("user", "Deny", method_arn)

def generate_policy(principal_id, effect, method_arn):
    
    policy = {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": method_arn
                }
            ]
        }
    }
    return policy
