import json

def lambda_handler(event, context):
    try:
        # Logs para entender o evento recebido
        print("Evento recebido: ", json.dumps(event))

        # Verifica se o cabeçalho de autorização existe e começa com 'Bearer'
        authorization_header = event['headers'].get('authorization', '')
        if not authorization_header.startswith('Bearer '):
            raise Exception("Token inválido! O token deve começar com 'Bearer'.")

        # Extrai o token do cabeçalho
        token = authorization_header.split(' ')[1]  # Remove 'Bearer' e pega o valor do token
        print("Token extraído:", token)

        # Valida se o token é numérico e possui exatamente 11 dígitos
        if not token.isdigit() or len(token) != 11:
            print("Token inválido: não é numérico ou não possui 11 dígitos.")
            # Retorna política negando acesso
            method_arn = "arn:aws:execute-api:us-east-2:148761639942:xlvi0r73m3/$default/POST/CPFAuth"
            return generate_policy("user", "Deny", method_arn)

        # Token válido, gera a política para permitir o acesso
        method_arn = "arn:aws:execute-api:us-east-2:148761639942:xlvi0r73m3/$default/POST/CPFAuth"
        policy = generate_policy("user", "Allow", method_arn)
        print("Policy gerada: ", json.dumps(policy))

        return policy

    except Exception as e:
        # Loga e lança o erro
        print(f"Erro ocorrido: {str(e)}")
        raise Exception("Erro no Lambda: " + str(e))

def generate_policy(principal_id, effect, method_arn):
    # Gera a política de autorização
    policy = {
        "principalId": principal_id,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": method_arn
                }
            ]
        }
    }
    return policy